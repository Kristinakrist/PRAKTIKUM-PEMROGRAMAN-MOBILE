package com.example.posttest3_108_kristina

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
