import 'package:flutter/material.dart';

abstract class TokoBunga extends StatelessWidget {
  const TokoBunga({super.key});
}

@override
Widget build(BuildContext context) {
  var GoogleFonts;
  return Material(
    child: Container(
      padding: EdgeInsets.only(top: 100, bottom: 40),
      decoration: BoxDecoration(
          color: Colors.white,
          image: DecorationImage(image: AssetImage('images/flower.jpeg'))),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Toko Bunga",
            style: GoogleFonts.lato(
              fontSize: 50,
              color: Colors.black,
            ),
          ),
          Column(
            children: [
              Text(
                "Mau Bunga Apa?",
                style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 17,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1,
                ),
              ),
              SizedBox(height: 80),
              InkWell(
                  onTap: () {},
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
                    decoration: BoxDecoration(
                      color: Colors.lightBlue,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "Get Start",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ))
            ],
          )
        ],
      ),
    ),
  );
}
